Building Taler
================

See doc/build-*.md for instructions on building the various
elements of the Taler Core reference implementation of Taler.
