Sample configuration files for:
```
SystemD: talerd.service
Upstart: talerd.conf
OpenRC:  talerd.openrc
         talerd.openrcconf
CentOS:  talerd.init
OS X:    org.bitcoin.talerd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
